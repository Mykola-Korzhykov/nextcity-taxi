const Footer = () => {
  return (
    <footer>
      <div className="container">
        <span> &#9400; INTERCITY </span>
      </div>
    </footer>
  );
};

export { Footer };
