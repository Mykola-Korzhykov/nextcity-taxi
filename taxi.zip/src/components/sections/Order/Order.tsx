import { FC, useState } from 'react'
import { useFieldArray, useForm, FormProvider } from 'react-hook-form'

import OrderList from './OrderList'
import IField from 'interfaces/IField'

import styles from './Order.module.scss'

type FormValues = {
    fields: IField[]
}

const Order: FC = () => {
    const form = useForm<FormValues>({
        defaultValues: {
          fields: [
            {route: '', entrance: ''},
            {route: '', entrance: ''}
          ]
        }
    });

    return (
        <FormProvider {...form}>
            <form className={styles.form}>
                <OrderList />
                <button type="submit" className={styles.submitButton}>
                    Заказать
                </button>
            </form>
        </FormProvider>
    )
}

export default Order;