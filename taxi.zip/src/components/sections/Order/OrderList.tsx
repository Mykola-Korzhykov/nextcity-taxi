import { FC, useEffect, useState } from 'react'
import { Container, Draggable, OnDropCallback } from 'react-smooth-dnd';
import { useFormContext, useFieldArray } from 'react-hook-form';

import { arrayMoveImmutable } from 'array-move';

import IField from 'interfaces/IField';
import OrderField from './OrderField';

import generateArray from '@helpers/generateArray';

import styles from './Order.module.scss'

type DropArguments = {
    removedIndex: number;
    addedIndex: number;
}

const OrderList: FC = () => {
    const { control } = useFormContext()
    const { fields, insert, remove, move, update } = useFieldArray({
        control,
        name: "fields"
    });

    const createField = (index: number) => {
        insert(1, {})
    };
    const removeField = (index: number) => {
        if(fields.length == 2 && index === 1) return false;
        remove(index);
    };

    const onDrop = ({ removedIndex, addedIndex }: DropArguments) => {
        const textarea: NodeListOf<HTMLTextAreaElement> = document.querySelectorAll(`.${styles.routeInput}[data-isfield="true"]`);

        const removedHeight = textarea[removedIndex].style.height
        const addedHeight = textarea[addedIndex].style.height

        move(removedIndex, addedIndex)
        
        textarea[addedIndex].style.height = removedHeight
        if(removedIndex !== addedIndex) {
            if(addedHeight !== '21px') {
                textarea[removedIndex].style.height = addedHeight
            } else {
                textarea[removedIndex].style.height = '21px'
            }
        }
    }

    return (
        // @ts-ignore
        <Container dragHandleSelector={`.${styles.dragButton}`} onDrop={onDrop} lockAxis='y' dragClass={styles.dragActive}>
            {fields && fields.map((field, index) => (
                // @ts-ignore
                <Draggable key={index} className={styles.draggable}>
                    <OrderField createField={createField} removeField={removeField} index={index} />
                </Draggable>
            ))}
        </Container>
    )
}

export default OrderList;