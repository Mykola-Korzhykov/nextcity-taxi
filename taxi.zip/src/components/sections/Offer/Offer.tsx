"use client";
import { FC } from "react";

import Order from "../Order/Order";

import styles from "./Offer.module.scss";

const Offer: FC = () => {
  return (
    <section className={styles.wrapper} id="section-offer">
      <div className="container">
        <div>
          <Order />
        </div>
      </div>
    </section>
  );
};

export { Offer };