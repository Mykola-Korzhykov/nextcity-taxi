import Rules from "@components/sections/Rules/Rules";

const Agreement = () => {
  return (
    <div className="next-page">
      <Rules />
    </div>
  );
};

export default Agreement;
