import { Offer } from "@sections/Offer/Offer";

export default function Home() {
  return (
    <div className="next-page">
      <Offer />
    </div>
  );
}
