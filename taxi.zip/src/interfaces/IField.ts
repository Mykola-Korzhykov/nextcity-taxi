export default interface IField {
    route: string;
    entrance: string;
}