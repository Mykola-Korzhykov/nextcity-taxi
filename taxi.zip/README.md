# Intercity Taxi | Front-End (Next JS) - DEVELOPMENT   
Front-End part of web-app for intercity taxi in Rossosh, Russia.